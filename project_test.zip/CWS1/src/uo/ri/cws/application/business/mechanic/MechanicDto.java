package uo.ri.cws.application.business.mechanic;

public class MechanicDto {

	public String id;
	public Long version;
	
	public String dni;
	public String name;
	public String surname;

}
