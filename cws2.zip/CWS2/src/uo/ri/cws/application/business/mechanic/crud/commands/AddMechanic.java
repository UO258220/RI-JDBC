package uo.ri.cws.application.business.mechanic.crud.commands;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;

import alb.util.jdbc.Jdbc;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicDto;
import uo.ri.cws.application.business.util.DtoAssembler;
import uo.ri.cws.application.persistence.PersistenceException;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;

public class AddMechanic {
	
	private MechanicDto mechanic;
	private MechanicGateway mg = PersistenceFactory.forMechanic();
	
	public AddMechanic(MechanicDto mechanic) {
		this.mechanic = mechanic;
	}
	
	public MechanicDto execute() throws BusinessException {
		Connection c = null;
		
		try {
			try {
				c = Jdbc.createThreadConnection();
				c.setAutoCommit(false);
				
				if (existMechanic()) {
					throw new BusinessException("A mechanic with this dni already exists");
				}

				mechanic.id = UUID.randomUUID().toString();
				mg.add(DtoAssembler.toRecord(mechanic));
			} catch (BusinessException e) {
				c.rollback();
				throw e;
			}		
			c.commit();
		} catch (SQLException | PersistenceException e) {
			throw new BusinessException();
		} finally {
			Jdbc.close(c);
		}
		return mechanic;
	}

	private boolean existMechanic() {
		return mg.findByDni(mechanic.dni).isEmpty();
	}

}
